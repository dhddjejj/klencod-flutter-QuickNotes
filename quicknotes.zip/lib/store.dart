import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// أنواع العناصر
enum ItemType { text, email, password, link }

const typeLabels = {
  ItemType.text: 'نص',
  ItemType.email: 'بريد',
  ItemType.password: 'كلمة سر',
  ItemType.link: 'رابط',
};

const typeIcons = {
  ItemType.text: Icons.notes_rounded,
  ItemType.email: Icons.alternate_email_rounded,
  ItemType.password: Icons.lock_rounded,
  ItemType.link: Icons.link_rounded,
};

/// ألوان وأيقونات القوائم (نخزّن الفهرس فقط)
const kColors = [0xFF7C5CFF, 0xFF00C2FF, 0xFF00E0B8, 0xFFFF5C8A, 0xFFFFB020, 0xFF8BE04E];
const kIcons = <IconData>[
  Icons.mail_rounded, Icons.key_rounded, Icons.person_rounded, Icons.language_rounded,
  Icons.credit_card_rounded, Icons.wifi_rounded, Icons.work_rounded, Icons.star_rounded,
];
Color listColor(int i) => Color(kColors[i % kColors.length]);
IconData listIcon(int i) => kIcons[i % kIcons.length];

class NoteItem {
  String id, title, value;
  ItemType type;
  NoteItem({required this.id, required this.title, required this.value, this.type = ItemType.text});

  Map<String, dynamic> toJson() => {'id': id, 't': title, 'v': value, 'ty': type.index};
  factory NoteItem.fromJson(Map<String, dynamic> j) => NoteItem(
        id: j['id'],
        title: j['t'],
        value: j['v'],
        type: ItemType.values[(j['ty'] ?? 0) as int],
      );
}

class NoteList {
  String id, name;
  int color, icon;
  List<NoteItem> items;
  NoteList({required this.id, required this.name, this.color = 0, this.icon = 0, List<NoteItem>? items})
      : items = items ?? [];

  Map<String, dynamic> toJson() =>
      {'id': id, 'n': name, 'c': color, 'i': icon, 'items': items.map((e) => e.toJson()).toList()};
  factory NoteList.fromJson(Map<String, dynamic> j) => NoteList(
        id: j['id'],
        name: j['n'],
        color: j['c'] ?? 0,
        icon: j['i'] ?? 0,
        items: ((j['items'] ?? []) as List)
            .map((e) => NoteItem.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

/// مخزن البيانات (محلي عبر shared_preferences)
class Store extends ChangeNotifier {
  static const _key = 'quicknotes_v1';
  List<NoteList> lists = [];
  bool lockEnabled = false;

  String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    await p.reload(); // مهم للفقاعة: تقرأ آخر بيانات محفوظة
    lockEnabled = p.getBool('lock') ?? false;
    final raw = p.getString(_key);
    if (raw != null) {
      try {
        lists = (jsonDecode(raw) as List)
            .map((e) => NoteList.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      } catch (_) {
        lists = [];
      }
    } else {
      lists = [NoteList(id: newId(), name: 'البريد الإلكتروني', color: 0, icon: 0)];
    }
    notifyListeners();
  }

  Future<void> save() async {
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setBool('lock', lockEnabled);
    await p.setString(_key, jsonEncode(lists.map((e) => e.toJson()).toList()));
  }

  NoteList? byId(String id) {
    for (final l in lists) {
      if (l.id == id) return l;
    }
    return null;
  }

  // ---- القوائم ----
  Future<void> addList(String name, int color, int icon) async {
    lists.add(NoteList(id: newId(), name: name, color: color, icon: icon));
    await save();
  }

  Future<void> editList(String id, String name, int color, int icon) async {
    final l = byId(id);
    if (l == null) return;
    l.name = name;
    l.color = color;
    l.icon = icon;
    await save();
  }

  Future<void> deleteList(String id) async {
    lists.removeWhere((l) => l.id == id);
    await save();
  }

  Future<void> reorderLists(int o, int n) async {
    final l = lists.removeAt(o);
    lists.insert(n, l);
    await save();
  }

  // ---- العناصر ----
  Future<void> addItem(String listId, String title, String value, ItemType type) async {
    byId(listId)?.items.add(NoteItem(id: newId(), title: title, value: value, type: type));
    await save();
  }

  Future<void> editItem(String listId, String itemId, String title, String value, ItemType type) async {
    final l = byId(listId);
    if (l == null) return;
    for (final it in l.items) {
      if (it.id == itemId) {
        it.title = title;
        it.value = value;
        it.type = type;
      }
    }
    await save();
  }

  Future<void> deleteItem(String listId, String itemId) async {
    byId(listId)?.items.removeWhere((i) => i.id == itemId);
    await save();
  }

  Future<void> reorderItems(String listId, int o, int n) async {
    final l = byId(listId);
    if (l == null) return;
    final it = l.items.removeAt(o);
    l.items.insert(n, it);
    await save();
  }
}

/// النسخة الرئيسية للتطبيق (الفقاعة تنشئ نسخة خاصة بها)
final store = Store();
